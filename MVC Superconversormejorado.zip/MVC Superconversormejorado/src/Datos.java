 
public class Datos {
	
	

	//Creo primer array
	final static float monedas[]={5F,2F,15F};
	
	//Segundo array con nombre de monedas
	final static String nombre_moneda[]={"Dolares","Corona Checa","Yen","Franco"};
	
	public Datos() {


	
	}

}
