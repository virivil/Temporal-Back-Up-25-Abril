//Superconversormejorado
 


public class User {

	//Definición de los objetos
	
	
	//a esta clase hay que añadirle static para que pueda funcionar... en proximos capitulos veremos porqué
	public static Direcciones s1;
	
	public static void main(String[] args) {

		//Creación de los objetos
		
		s1=new Direcciones();
		s1.setVisible(true);
	}

}
